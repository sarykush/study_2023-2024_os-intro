#! /bin/bash
tar -cvf ~/work/study/2023-2024/'Операционные системы'/os-intro/labs/lab12/backup/backup_$(date +%Y%m%d-%H%M%S).tar $0
